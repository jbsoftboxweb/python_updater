import subprocess, sys
# version 2.0
subprocess.Popen(["python", "updater.py"])
sys.exit()  # close main app
